import tkinter as tk
import random


# Função para criar o tabuleiro do jogo
def criar_tabuleiro():
    cartas = [chr(i) for i in range (97, 97 + 8)] #codigo chr para trocar os simbolos
    pares = cartas * 2
    random.shuffle(pares)
    return pares


WHITE = (255, 255, 255)
#RED = (115, 0, 0)
#PINK = (255, 192, 203)


# Função para exibir o estado das cartas
def mostrar_cartas():
    for i, botao in enumerate(botoes):
        if visiveis[i]:
            botao.config(text=tabuleiro[i])
        else:
            botao.config(text="")

# Função para lidar com o clique em um botão
def clique(botao, i):
    global primeiro_clique, segundo_clique, visiveis
    if visiveis[i] or segundo_clique is not None:
        return

    visiveis[i] = True
    mostrar_cartas()

    if primeiro_clique is None:
        primeiro_clique = i
    elif segundo_clique is None:
        segundo_clique = i
        janela.after(1000, verificar_pares)

def verificar_pares():
    global primeiro_clique, segundo_clique
    if tabuleiro[primeiro_clique] != tabuleiro[segundo_clique]:
        visiveis[primeiro_clique] = False
        visiveis[segundo_clique] = False
    primeiro_clique = None
    segundo_clique = None
    mostrar_cartas()
    if all(visiveis):
        janela.title("Você ganhou!")

# Configuração da interface gráfica
janela = tk.Tk()
janela.title("Jogo da Memória")


tabuleiro = criar_tabuleiro()
visiveis = [False] * len(tabuleiro)
primeiro_clique = None
segundo_clique = None

botoes = []

# Cria a grade de botões para o tabuleiro
for i in range(len(tabuleiro)):
    botao = tk.Button(janela, bg= "light pink", text="", width=6, height=3,
                      command=lambda i=i: clique(botao, i))
    botao.grid(row=i//4, column=i%4)
    botoes.append(botao)

janela.mainloop()

# https://www.tcl.tk/man/tcl8.6/TkCmd/contents.htm